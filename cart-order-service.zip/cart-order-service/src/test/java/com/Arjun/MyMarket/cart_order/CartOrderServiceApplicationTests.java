package com.Arjun.MyMarket.cart_order;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CartOrderServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
